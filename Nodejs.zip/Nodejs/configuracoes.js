exports.mycfg = function () {
    return ("Página de configurações");
  };
  

