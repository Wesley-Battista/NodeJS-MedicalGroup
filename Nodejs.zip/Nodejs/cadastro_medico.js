exports.mycadmed = function () {
    return ("Página de cadastro do médico");
  };
  
