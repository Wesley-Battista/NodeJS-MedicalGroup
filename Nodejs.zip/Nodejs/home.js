exports.mg = function () {
    return ("Página inicial");
  };
  
