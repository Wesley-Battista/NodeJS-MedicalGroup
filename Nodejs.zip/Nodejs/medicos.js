exports.mymed = function () {
    return ("Página dos médicos");
  };
  
