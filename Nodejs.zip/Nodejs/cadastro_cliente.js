exports.mycadcli = function () {
    return ("Página de cadastro do cliente");
  };
  
