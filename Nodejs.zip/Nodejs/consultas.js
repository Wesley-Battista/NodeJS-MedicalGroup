exports.mycon = function () {
    return ("Página de consultas");
  };
  
