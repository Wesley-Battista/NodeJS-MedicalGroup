
exports.mypag = function () {
    return ("Página de pagamentos");
  };
  

