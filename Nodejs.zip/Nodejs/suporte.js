exports.mysup = function () {
    return ("Página de suporte");
  };
  

